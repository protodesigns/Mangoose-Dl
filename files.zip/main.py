import customtkinter as ctk
import tkinter as tk
from tkinter import filedialog, messagebox
import threading
import queue
import os
import json
import time
import socket
import subprocess
import sys
from datetime import datetime
from pathlib import Path
import yt_dlp

# ── App Config ────────────────────────────────────────────────────────────────
APP_NAME    = "DL Mongoose"
APP_VERSION = "1.0.0"
CONFIG_FILE = os.path.join(os.path.expanduser("~"), ".dlmongoose_config.json")

# ── Theme Colors ──────────────────────────────────────────────────────────────
BG_DEEP      = "#050B18"
BG_PANEL     = "#0A1628"
GLASS_BG     = "#0D1E35"
GLASS_BORDER = "#1A3A5C"
BLUE_ACCENT  = "#4B7BEC"
PURPLE_ACC   = "#A855F7"
CYAN_ACC     = "#06B6D4"
TEXT_MAIN    = "#E8F4FD"
TEXT_DIM     = "#7BA7C9"
SUCCESS      = "#10B981"
ERROR_RED    = "#EF4444"
WARNING_ORG  = "#F59E0B"
TRAY_GREEN   = "#22C55E"

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

# ── Config Manager ────────────────────────────────────────────────────────────
class Config:
    defaults = {
        "download_path": str(Path.home() / "Downloads"),
        "remember_path": True,
        "platform": "YouTube",
        "video_quality": "Best",
        "audio_quality": "320",
        "skip_delete_warning": False,
        "minimize_to_tray": True,
    }

    def __init__(self):
        self.data = dict(self.defaults)
        self.load()

    def load(self):
        try:
            if os.path.exists(CONFIG_FILE):
                with open(CONFIG_FILE) as f:
                    self.data.update(json.load(f))
        except:
            pass

    def save(self):
        try:
            with open(CONFIG_FILE, "w") as f:
                json.dump(self.data, f, indent=2)
        except:
            pass

    def get(self, key):
        return self.data.get(key, self.defaults.get(key))

    def set(self, key, value):
        self.data[key] = value
        self.save()

config = Config()

# ── Internet Check ────────────────────────────────────────────────────────────
def check_internet():
    try:
        socket.setdefaulttimeout(3)
        socket.socket(socket.AF_INET, socket.SOCK_STREAM).connect(("8.8.8.8", 53))
        return True
    except:
        return False

# ══════════════════════════════════════════════════════════════════════════════
#  SPLASH SCREEN
# ══════════════════════════════════════════════════════════════════════════════
class SplashScreen(ctk.CTkToplevel):
    def __init__(self):
        super().__init__()
        self.overrideredirect(True)
        self.configure(fg_color=BG_DEEP)
        w, h = 480, 300
        sw = self.winfo_screenwidth()
        sh = self.winfo_screenheight()
        x  = (sw - w) // 2
        y  = (sh - h) // 2
        self.geometry(f"{w}x{h}+{x}+{y}")
        self.attributes("-topmost", True)
        self._build()
        self._animate()

    def _build(self):
        # Outer glass frame
        outer = ctk.CTkFrame(self, fg_color=GLASS_BG, corner_radius=28,
                             border_width=1, border_color=GLASS_BORDER)
        outer.pack(fill="both", expand=True, padx=2, pady=2)

        # Logo emoji area
        self.logo_lbl = ctk.CTkLabel(outer, text="🦡", font=("Segoe UI Emoji", 56))
        self.logo_lbl.pack(pady=(38, 4))

        ctk.CTkLabel(outer, text=APP_NAME,
                     font=("Georgia", 28, "bold"),
                     text_color=TEXT_MAIN).pack()
        ctk.CTkLabel(outer, text="Fast • Clean • Unstoppable",
                     font=("Segoe UI", 11),
                     text_color=TEXT_DIM).pack(pady=(2, 18))

        # Progress bar
        self.prog = ctk.CTkProgressBar(outer, width=300, height=6,
                                       corner_radius=6,
                                       fg_color=GLASS_BORDER,
                                       progress_color=BLUE_ACCENT)
        self.prog.set(0)
        self.prog.pack(pady=(0, 10))

        self.status_lbl = ctk.CTkLabel(outer, text="Initializing...",
                                       font=("Segoe UI", 10),
                                       text_color=TEXT_DIM)
        self.status_lbl.pack()

        ctk.CTkLabel(outer, text=f"v{APP_VERSION}",
                     font=("Segoe UI", 9),
                     text_color=GLASS_BORDER).pack(pady=(10, 0))

    def _animate(self):
        steps = [
            (0.2, "Loading components..."),
            (0.5, "Checking environment..."),
            (0.75, "Almost there..."),
            (1.0, "Ready!"),
        ]
        def run(i=0):
            if i < len(steps):
                val, msg = steps[i]
                self.prog.set(val)
                self.status_lbl.configure(text=msg)
                self.after(500, lambda: run(i + 1))
            else:
                self.after(300, self.destroy)
        run()


# ══════════════════════════════════════════════════════════════════════════════
#  ERROR DIALOG
# ══════════════════════════════════════════════════════════════════════════════
class ErrorDialog(ctk.CTkToplevel):
    def __init__(self, parent, title="Error", message="An error occurred."):
        super().__init__(parent)
        self.title(title)
        self.configure(fg_color=BG_DEEP)
        self.resizable(False, False)
        w, h = 460, 260
        px = parent.winfo_x() + (parent.winfo_width() - w) // 2
        py = parent.winfo_y() + (parent.winfo_height() - h) // 2
        self.geometry(f"{w}x{h}+{px}+{py}")
        self.attributes("-topmost", True)
        self.grab_set()
        self._build(title, message)

    def _build(self, title, message):
        frame = ctk.CTkFrame(self, fg_color=GLASS_BG, corner_radius=24,
                             border_width=1, border_color=GLASS_BORDER)
        frame.pack(fill="both", expand=True, padx=2, pady=2)

        ctk.CTkLabel(frame, text="⚠️  " + title,
                     font=("Segoe UI", 15, "bold"),
                     text_color=ERROR_RED).pack(pady=(22, 8))

        # Scrollable error text
        txt = ctk.CTkTextbox(frame, height=90, corner_radius=12,
                             fg_color=BG_DEEP, border_color=GLASS_BORDER,
                             border_width=1, text_color=TEXT_MAIN,
                             font=("Consolas", 11), wrap="word")
        txt.pack(padx=20, fill="x")
        txt.insert("1.0", message)
        txt.configure(state="disabled")

        btn_row = ctk.CTkFrame(frame, fg_color="transparent")
        btn_row.pack(pady=16)

        def copy_err():
            self.clipboard_clear()
            self.clipboard_append(message)
            copy_btn.configure(text="✅ Copied!")
            self.after(1500, lambda: copy_btn.configure(text="📋 Copy Error"))

        copy_btn = ctk.CTkButton(btn_row, text="📋 Copy Error", width=130,
                                 corner_radius=20, fg_color=GLASS_BORDER,
                                 hover_color=BLUE_ACCENT, command=copy_err)
        copy_btn.pack(side="left", padx=8)

        ctk.CTkButton(btn_row, text="Close", width=100, corner_radius=20,
                      fg_color=ERROR_RED, hover_color="#C0392B",
                      command=self.destroy).pack(side="left", padx=8)


# ══════════════════════════════════════════════════════════════════════════════
#  QUEUE ITEM WIDGET
# ══════════════════════════════════════════════════════════════════════════════
class QueueItem(ctk.CTkFrame):
    def __init__(self, parent, item_id, title, url, on_cancel, on_delete, **kw):
        super().__init__(parent, fg_color=GLASS_BG, corner_radius=16,
                         border_width=1, border_color=GLASS_BORDER, **kw)
        self.item_id   = item_id
        self.url       = url
        self.cancelled = False
        self.on_cancel = on_cancel
        self.on_delete = on_delete
        self._build(title)

    def _build(self, title):
        self.pack(fill="x", padx=10, pady=4)

        top = ctk.CTkFrame(self, fg_color="transparent")
        top.pack(fill="x", padx=14, pady=(10, 4))

        self.title_lbl = ctk.CTkLabel(top, text=title[:55] + ("…" if len(title) > 55 else ""),
                                      font=("Segoe UI", 12, "bold"),
                                      text_color=TEXT_MAIN, anchor="w")
        self.title_lbl.pack(side="left", fill="x", expand=True)

        self.status_lbl = ctk.CTkLabel(top, text="Queued",
                                       font=("Segoe UI", 10),
                                       text_color=TEXT_DIM)
        self.status_lbl.pack(side="right")

        self.prog = ctk.CTkProgressBar(self, height=5, corner_radius=4,
                                       fg_color=BG_DEEP,
                                       progress_color=BLUE_ACCENT)
        self.prog.set(0)
        self.prog.pack(fill="x", padx=14, pady=(0, 6))

        self.speed_lbl = ctk.CTkLabel(self, text="",
                                      font=("Segoe UI", 10),
                                      text_color=CYAN_ACC)
        self.speed_lbl.pack(anchor="w", padx=14)

        btn_row = ctk.CTkFrame(self, fg_color="transparent")
        btn_row.pack(anchor="e", padx=14, pady=(4, 10))

        self.cancel_btn = ctk.CTkButton(btn_row, text="Cancel", width=80,
                                        height=26, corner_radius=14,
                                        fg_color=WARNING_ORG, hover_color="#D97706",
                                        font=("Segoe UI", 11),
                                        command=self._cancel)
        self.cancel_btn.pack(side="left", padx=4)

        self.delete_btn = ctk.CTkButton(btn_row, text="Remove", width=80,
                                        height=26, corner_radius=14,
                                        fg_color=ERROR_RED, hover_color="#C0392B",
                                        font=("Segoe UI", 11),
                                        command=lambda: self.on_delete(self.item_id))
        self.delete_btn.pack(side="left", padx=4)

    def _cancel(self):
        self.cancelled = True
        self.on_cancel(self.item_id)
        self.cancel_btn.configure(state="disabled", text="Cancelled")
        self.status_lbl.configure(text="Cancelled", text_color=WARNING_ORG)

    def update_progress(self, pct, speed, status_text, color=BLUE_ACCENT):
        self.prog.configure(progress_color=color)
        self.prog.set(pct / 100)
        self.speed_lbl.configure(text=speed)
        self.status_lbl.configure(text=status_text)

    def mark_done(self):
        self.prog.configure(progress_color=SUCCESS)
        self.prog.set(1.0)
        self.status_lbl.configure(text="✅ Done", text_color=SUCCESS)
        self.speed_lbl.configure(text="")
        self.cancel_btn.configure(state="disabled", text="Done")

    def mark_error(self):
        self.prog.configure(progress_color=ERROR_RED)
        self.status_lbl.configure(text="❌ Error", text_color=ERROR_RED)
        self.cancel_btn.configure(state="disabled")


# ══════════════════════════════════════════════════════════════════════════════
#  DOWNLOAD HISTORY ITEM
# ══════════════════════════════════════════════════════════════════════════════
class HistoryItem(ctk.CTkFrame):
    def __init__(self, parent, entry, on_delete, **kw):
        super().__init__(parent, fg_color=GLASS_BG, corner_radius=14,
                         border_width=1, border_color=GLASS_BORDER, **kw)
        self.entry     = entry
        self.on_delete = on_delete
        self.selected  = False
        self._build()

    def _build(self):
        self.pack(fill="x", padx=10, pady=3)
        row = ctk.CTkFrame(self, fg_color="transparent")
        row.pack(fill="x", padx=12, pady=10)

        # Checkbox
        self.check_var = tk.BooleanVar()
        self.chk = ctk.CTkCheckBox(row, text="", variable=self.check_var,
                                   width=20, checkbox_width=18, checkbox_height=18,
                                   corner_radius=6, fg_color=BLUE_ACCENT,
                                   border_color=GLASS_BORDER)
        self.chk.pack(side="left", padx=(0, 8))

        info = ctk.CTkFrame(row, fg_color="transparent")
        info.pack(side="left", fill="x", expand=True)

        name = os.path.basename(self.entry.get("path", "Unknown"))
        ctk.CTkLabel(info, text=name[:50] + ("…" if len(name) > 50 else ""),
                     font=("Segoe UI", 12, "bold"),
                     text_color=TEXT_MAIN, anchor="w").pack(anchor="w")

        ts = self.entry.get("timestamp", "")
        ctk.CTkLabel(info, text=ts,
                     font=("Segoe UI", 10),
                     text_color=TEXT_DIM, anchor="w").pack(anchor="w")

        btn_row = ctk.CTkFrame(row, fg_color="transparent")
        btn_row.pack(side="right")

        ctk.CTkButton(btn_row, text="📂 Open", width=80, height=26,
                      corner_radius=14, fg_color=GLASS_BORDER,
                      hover_color=BLUE_ACCENT, font=("Segoe UI", 11),
                      command=self._open_folder).pack(side="left", padx=3)

        ctk.CTkButton(btn_row, text="🗑 Delete", width=80, height=26,
                      corner_radius=14, fg_color=ERROR_RED,
                      hover_color="#C0392B", font=("Segoe UI", 11),
                      command=self._delete).pack(side="left", padx=3)

    def _open_folder(self):
        path = self.entry.get("path", "")
        if os.path.exists(path):
            subprocess.run(["explorer", "/select,", path])
        else:
            pass

    def _delete(self):
        self.on_delete(self)

    def is_selected(self):
        return self.check_var.get()


# ══════════════════════════════════════════════════════════════════════════════
#  MAIN APPLICATION
# ══════════════════════════════════════════════════════════════════════════════
class DLMongoose(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title(APP_NAME)
        self.configure(fg_color=BG_DEEP)
        self.geometry("820x680")
        self.minsize(760, 600)
        self.protocol("WM_DELETE_WINDOW", self._on_close)

        # State
        self.queue_items   = {}
        self.queue_counter = 0
        self.dl_queue      = queue.Queue()
        self.cancel_flags  = {}
        self.history       = []
        self.internet_ok   = True
        self.no_net_overlay = None

        # Load history
        self._load_history()

        # Build UI
        self._build_ui()

        # Start workers
        threading.Thread(target=self._download_worker, daemon=True).start()
        threading.Thread(target=self._internet_watcher, daemon=True).start()

        # System tray (Windows)
        self._setup_tray()

    # ── UI Builder ────────────────────────────────────────────────────────────
    def _build_ui(self):
        # Top bar
        topbar = ctk.CTkFrame(self, fg_color=GLASS_BG, corner_radius=0,
                              border_width=0, height=54)
        topbar.pack(fill="x", side="top")
        topbar.pack_propagate(False)

        ctk.CTkLabel(topbar, text="🦡 " + APP_NAME,
                     font=("Georgia", 18, "bold"),
                     text_color=TEXT_MAIN).pack(side="left", padx=20, pady=12)

        # Support button
        ctk.CTkButton(topbar, text="💛 Support Me",
                      width=130, height=32, corner_radius=20,
                      fg_color=WARNING_ORG, hover_color="#D97706",
                      font=("Segoe UI", 12, "bold"),
                      command=self._open_support).pack(side="right", padx=16, pady=10)

        ctk.CTkButton(topbar, text="⊟ Tray",
                      width=70, height=32, corner_radius=20,
                      fg_color=GLASS_BORDER, hover_color=BLUE_ACCENT,
                      font=("Segoe UI", 11),
                      command=self._minimize_to_tray).pack(side="right", padx=4, pady=10)

        # Tab view
        self.tabs = ctk.CTkTabview(self, corner_radius=20,
                                   fg_color=GLASS_BG,
                                   segmented_button_fg_color=BG_PANEL,
                                   segmented_button_selected_color=BLUE_ACCENT,
                                   segmented_button_selected_hover_color="#3A6AD4",
                                   segmented_button_unselected_color=BG_PANEL,
                                   segmented_button_unselected_hover_color=GLASS_BORDER,
                                   text_color=TEXT_MAIN,
                                   border_color=GLASS_BORDER, border_width=1)
        self.tabs.pack(fill="both", expand=True, padx=14, pady=(10, 14))
        self.tabs.add("⬇  Download")
        self.tabs.add("📋  Queue")
        self.tabs.add("📁  History")

        self._build_download_tab()
        self._build_queue_tab()
        self._build_history_tab()

    # ── Download Tab ──────────────────────────────────────────────────────────
    def _build_download_tab(self):
        tab = self.tabs.tab("⬇  Download")
        tab.configure(fg_color="transparent")

        scroll = ctk.CTkScrollableFrame(tab, fg_color="transparent",
                                        scrollbar_button_color=GLASS_BORDER)
        scroll.pack(fill="both", expand=True)

        # URL Input
        url_card = ctk.CTkFrame(scroll, fg_color=GLASS_BG, corner_radius=20,
                                border_width=1, border_color=GLASS_BORDER)
        url_card.pack(fill="x", padx=6, pady=(8, 6))

        ctk.CTkLabel(url_card, text="YouTube URL",
                     font=("Segoe UI", 12, "bold"),
                     text_color=TEXT_DIM).pack(anchor="w", padx=18, pady=(14, 4))

        url_row = ctk.CTkFrame(url_card, fg_color="transparent")
        url_row.pack(fill="x", padx=18, pady=(0, 14))

        self.url_entry = ctk.CTkEntry(url_row, placeholder_text="Paste YouTube link here...",
                                      height=42, corner_radius=14,
                                      fg_color=BG_DEEP, border_color=GLASS_BORDER,
                                      text_color=TEXT_MAIN,
                                      placeholder_text_color=TEXT_DIM,
                                      font=("Segoe UI", 13))
        self.url_entry.pack(side="left", fill="x", expand=True, padx=(0, 10))

        ctk.CTkButton(url_row, text="Add to Queue", width=130, height=42,
                      corner_radius=14, fg_color=BLUE_ACCENT,
                      hover_color="#3A6AD4", font=("Segoe UI", 13, "bold"),
                      command=self._add_to_queue).pack(side="right")

        # Options card
        opt_card = ctk.CTkFrame(scroll, fg_color=GLASS_BG, corner_radius=20,
                                border_width=1, border_color=GLASS_BORDER)
        opt_card.pack(fill="x", padx=6, pady=6)

        ctk.CTkLabel(opt_card, text="Options",
                     font=("Segoe UI", 12, "bold"),
                     text_color=TEXT_DIM).pack(anchor="w", padx=18, pady=(14, 8))

        opt_grid = ctk.CTkFrame(opt_card, fg_color="transparent")
        opt_grid.pack(fill="x", padx=18, pady=(0, 14))
        opt_grid.columnconfigure((0, 1), weight=1)

        # Platform
        ctk.CTkLabel(opt_grid, text="Platform",
                     font=("Segoe UI", 11), text_color=TEXT_DIM).grid(
            row=0, column=0, sticky="w", pady=4)
        self.platform_var = ctk.StringVar(value=config.get("platform"))
        ctk.CTkOptionMenu(opt_grid, values=["YouTube", "YouTube Music"],
                          variable=self.platform_var,
                          width=200, height=36, corner_radius=12,
                          fg_color=BG_DEEP, button_color=BLUE_ACCENT,
                          button_hover_color="#3A6AD4",
                          text_color=TEXT_MAIN,
                          command=self._on_platform_change).grid(
            row=1, column=0, sticky="w", pady=(0, 10), padx=(0, 10))

        # Quality
        ctk.CTkLabel(opt_grid, text="Quality",
                     font=("Segoe UI", 11), text_color=TEXT_DIM).grid(
            row=0, column=1, sticky="w", pady=4)
        self.quality_var = ctk.StringVar(value=config.get("video_quality"))
        self.quality_menu = ctk.CTkOptionMenu(opt_grid,
                                              values=["Best", "1080p", "720p", "480p", "360p", "Audio Only (MP3)"],
                                              variable=self.quality_var,
                                              width=200, height=36, corner_radius=12,
                                              fg_color=BG_DEEP, button_color=BLUE_ACCENT,
                                              button_hover_color="#3A6AD4",
                                              text_color=TEXT_MAIN,
                                              command=self._on_quality_change)
        self.quality_menu.grid(row=1, column=1, sticky="w", pady=(0, 10))

        # Audio quality (shown for MP3)
        self.audio_lbl = ctk.CTkLabel(opt_grid, text="MP3 Quality",
                                      font=("Segoe UI", 11), text_color=TEXT_DIM)
        self.audio_var = ctk.StringVar(value=config.get("audio_quality"))
        self.audio_menu = ctk.CTkOptionMenu(opt_grid,
                                            values=["320", "256", "192", "128", "96"],
                                            variable=self.audio_var,
                                            width=200, height=36, corner_radius=12,
                                            fg_color=BG_DEEP, button_color=PURPLE_ACC,
                                            button_hover_color="#9333EA",
                                            text_color=TEXT_MAIN)

        # Download path
        path_card = ctk.CTkFrame(scroll, fg_color=GLASS_BG, corner_radius=20,
                                 border_width=1, border_color=GLASS_BORDER)
        path_card.pack(fill="x", padx=6, pady=6)

        ctk.CTkLabel(path_card, text="Save Location",
                     font=("Segoe UI", 12, "bold"),
                     text_color=TEXT_DIM).pack(anchor="w", padx=18, pady=(14, 8))

        path_row = ctk.CTkFrame(path_card, fg_color="transparent")
        path_row.pack(fill="x", padx=18, pady=(0, 10))

        self.path_var = tk.StringVar(value=config.get("download_path"))
        self.path_entry = ctk.CTkEntry(path_row, textvariable=self.path_var,
                                       height=38, corner_radius=12,
                                       fg_color=BG_DEEP, border_color=GLASS_BORDER,
                                       text_color=TEXT_MAIN, font=("Segoe UI", 11))
        self.path_entry.pack(side="left", fill="x", expand=True, padx=(0, 10))

        ctk.CTkButton(path_row, text="Browse", width=90, height=38,
                      corner_radius=12, fg_color=GLASS_BORDER,
                      hover_color=BLUE_ACCENT, font=("Segoe UI", 11),
                      command=self._browse_path).pack(side="right")

        remember_row = ctk.CTkFrame(path_card, fg_color="transparent")
        remember_row.pack(anchor="w", padx=18, pady=(0, 14))

        self.remember_var = tk.BooleanVar(value=config.get("remember_path"))
        ctk.CTkCheckBox(remember_row, text="Remember this path",
                        variable=self.remember_var,
                        font=("Segoe UI", 11), text_color=TEXT_DIM,
                        fg_color=BLUE_ACCENT, border_color=GLASS_BORDER,
                        corner_radius=6,
                        command=self._on_remember).pack(side="left")

    # ── Queue Tab ─────────────────────────────────────────────────────────────
    def _build_queue_tab(self):
        tab = self.tabs.tab("📋  Queue")
        tab.configure(fg_color="transparent")

        top_row = ctk.CTkFrame(tab, fg_color="transparent")
        top_row.pack(fill="x", padx=10, pady=(8, 4))

        ctk.CTkLabel(top_row, text="Download Queue",
                     font=("Segoe UI", 14, "bold"),
                     text_color=TEXT_MAIN).pack(side="left")

        ctk.CTkButton(top_row, text="Clear Done", width=100, height=30,
                      corner_radius=14, fg_color=GLASS_BORDER,
                      hover_color=BLUE_ACCENT, font=("Segoe UI", 11),
                      command=self._clear_done).pack(side="right")

        self.queue_scroll = ctk.CTkScrollableFrame(tab, fg_color="transparent",
                                                   scrollbar_button_color=GLASS_BORDER)
        self.queue_scroll.pack(fill="both", expand=True, padx=4, pady=4)

        self.empty_queue_lbl = ctk.CTkLabel(self.queue_scroll,
                                            text="Queue is empty\nAdd links in the Download tab",
                                            font=("Segoe UI", 13),
                                            text_color=TEXT_DIM)
        self.empty_queue_lbl.pack(expand=True, pady=80)

    # ── History Tab ───────────────────────────────────────────────────────────
    def _build_history_tab(self):
        tab = self.tabs.tab("📁  History")
        tab.configure(fg_color="transparent")

        top_row = ctk.CTkFrame(tab, fg_color="transparent")
        top_row.pack(fill="x", padx=10, pady=(8, 4))

        ctk.CTkLabel(top_row, text="Recent Downloads",
                     font=("Segoe UI", 14, "bold"),
                     text_color=TEXT_MAIN).pack(side="left")

        ctk.CTkButton(top_row, text="🗑 Delete Selected", width=130, height=30,
                      corner_radius=14, fg_color=ERROR_RED,
                      hover_color="#C0392B", font=("Segoe UI", 11),
                      command=self._delete_selected).pack(side="right")

        self.history_scroll = ctk.CTkScrollableFrame(tab, fg_color="transparent",
                                                     scrollbar_button_color=GLASS_BORDER)
        self.history_scroll.pack(fill="both", expand=True, padx=4, pady=4)

        self.empty_hist_lbl = ctk.CTkLabel(self.history_scroll,
                                           text="No downloads yet",
                                           font=("Segoe UI", 13),
                                           text_color=TEXT_DIM)
        self.history_widgets = []
        self._refresh_history_ui()

    # ── Internet Overlay ──────────────────────────────────────────────────────
    def _show_no_internet(self):
        if self.no_net_overlay:
            return
        self.no_net_overlay = ctk.CTkFrame(self, fg_color="#00000099",
                                           corner_radius=0)
        self.no_net_overlay.place(relx=0, rely=0, relwidth=1, relheight=1)

        card = ctk.CTkFrame(self.no_net_overlay, fg_color=GLASS_BG,
                            corner_radius=24, border_width=1,
                            border_color=ERROR_RED, width=360, height=220)
        card.place(relx=0.5, rely=0.5, anchor="center")
        card.pack_propagate(False)

        ctk.CTkLabel(card, text="🔴", font=("Segoe UI Emoji", 40)).pack(pady=(30, 4))
        ctk.CTkLabel(card, text="No Internet Connection",
                     font=("Segoe UI", 15, "bold"),
                     text_color=ERROR_RED).pack()
        ctk.CTkLabel(card, text="Please check your connection",
                     font=("Segoe UI", 11), text_color=TEXT_DIM).pack(pady=4)

        ctk.CTkButton(card, text="🔄 Retry", width=120, height=36,
                      corner_radius=18, fg_color=BLUE_ACCENT,
                      hover_color="#3A6AD4", font=("Segoe UI", 12, "bold"),
                      command=self._retry_internet).pack(pady=(10, 0))

    def _hide_no_internet(self):
        if self.no_net_overlay:
            self.no_net_overlay.destroy()
            self.no_net_overlay = None

    def _retry_internet(self):
        if check_internet():
            self._hide_no_internet()
            self.internet_ok = True

    def _internet_watcher(self):
        while True:
            status = check_internet()
            if status != self.internet_ok:
                self.internet_ok = status
                if status:
                    self.after(0, self._hide_no_internet)
                else:
                    self.after(0, self._show_no_internet)
            time.sleep(5)

    # ── Download Logic ────────────────────────────────────────────────────────
    def _add_to_queue(self):
        if not self.internet_ok:
            return
        url = self.url_entry.get().strip()
        if not url:
            ErrorDialog(self, "No URL", "Please paste a YouTube URL first.")
            return
        if "youtube.com" not in url and "youtu.be" not in url:
            ErrorDialog(self, "Invalid URL", f"This doesn't look like a YouTube link:\n{url}")
            return

        self.queue_counter += 1
        item_id = self.queue_counter
        self.cancel_flags[item_id] = False

        title = f"Item #{item_id} — fetching title..."
        widget = QueueItem(self.queue_scroll, item_id, title, url,
                           on_cancel=self._cancel_item,
                           on_delete=self._remove_item)

        self.queue_items[item_id] = {"widget": widget, "url": url, "done": False}
        self.empty_queue_lbl.pack_forget()
        self.dl_queue.put(item_id)
        self.url_entry.delete(0, "end")

        # Switch to queue tab
        self.tabs.set("📋  Queue")

    def _download_worker(self):
        while True:
            item_id = self.dl_queue.get()
            if item_id not in self.queue_items:
                continue
            if self.cancel_flags.get(item_id):
                continue
            self._do_download(item_id)
            self.dl_queue.task_done()

    def _do_download(self, item_id):
        info        = self.queue_items[item_id]
        url         = info["url"]
        widget      = info["widget"]
        out_path    = self.path_var.get()
        quality     = self.quality_var.get()
        audio_q     = self.audio_var.get()
        is_mp3      = quality == "Audio Only (MP3)"
        is_yt_music = self.platform_var.get() == "YouTube Music"

        os.makedirs(out_path, exist_ok=True)

        def progress_hook(d):
            if self.cancel_flags.get(item_id):
                raise Exception("Cancelled by user")
            if d["status"] == "downloading":
                pct   = d.get("_percent_str", "0%").strip().replace("%", "")
                speed = d.get("_speed_str", "").strip()
                eta   = d.get("_eta_str", "").strip()
                try:
                    pct_f = float(pct)
                except:
                    pct_f = 0
                self.after(0, lambda p=pct_f, s=speed, e=eta:
                           widget.update_progress(p, f"{s}  ETA {e}", f"{p:.0f}%"))

            elif d["status"] == "finished":
                self.after(0, lambda: widget.update_progress(100, "", "Processing...", PURPLE_ACC))

        # Build ydl opts
        if is_mp3 or is_yt_music:
            ydl_opts = {
                "format": "bestaudio/best",
                "postprocessors": [{
                    "key": "FFmpegExtractAudio",
                    "preferredcodec": "mp3",
                    "preferredquality": audio_q,
                }],
                "outtmpl": os.path.join(out_path, "%(title)s.%(ext)s"),
                "progress_hooks": [progress_hook],
                "quiet": True,
                "no_warnings": True,
            }
        else:
            q_map = {"Best": "bestvideo+bestaudio/best",
                     "1080p": "bestvideo[height<=1080]+bestaudio/best",
                     "720p":  "bestvideo[height<=720]+bestaudio/best",
                     "480p":  "bestvideo[height<=480]+bestaudio/best",
                     "360p":  "bestvideo[height<=360]+bestaudio/best"}
            ydl_opts = {
                "format": q_map.get(quality, "bestvideo+bestaudio/best"),
                "outtmpl": os.path.join(out_path, "%(title)s.%(ext)s"),
                "progress_hooks": [progress_hook],
                "quiet": True,
                "no_warnings": True,
                "merge_output_format": "mp4",
            }

        try:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                meta = ydl.extract_info(url, download=False)
                title = meta.get("title", f"Item #{item_id}")
                self.after(0, lambda t=title: widget.title_lbl.configure(
                    text=t[:55] + ("…" if len(t) > 55 else "")))
                self.after(0, lambda: widget.status_lbl.configure(text="Downloading..."))

                if not self.cancel_flags.get(item_id):
                    ydl.download([url])

            if not self.cancel_flags.get(item_id):
                self.after(0, widget.mark_done)
                info["done"] = True
                # Add to history
                ext = "mp3" if (is_mp3 or is_yt_music) else "mp4"
                file_path = os.path.join(out_path, f"{title}.{ext}")
                self._add_history(title, file_path)

        except Exception as e:
            err = str(e)
            if "Cancelled" in err:
                pass
            else:
                self.after(0, widget.mark_error)
                self.after(0, lambda msg=err: ErrorDialog(
                    self, "Download Error", msg))

    def _cancel_item(self, item_id):
        self.cancel_flags[item_id] = True

    def _remove_item(self, item_id):
        if item_id in self.queue_items:
            self.cancel_flags[item_id] = True
            w = self.queue_items[item_id]["widget"]
            w.destroy()
            del self.queue_items[item_id]
        if not self.queue_items:
            self.empty_queue_lbl.pack(expand=True, pady=80)

    def _clear_done(self):
        to_remove = [k for k, v in self.queue_items.items() if v.get("done")]
        for k in to_remove:
            self.queue_items[k]["widget"].destroy()
            del self.queue_items[k]
        if not self.queue_items:
            self.empty_queue_lbl.pack(expand=True, pady=80)

    # ── History ───────────────────────────────────────────────────────────────
    HISTORY_FILE = os.path.join(os.path.expanduser("~"), ".dlmongoose_history.json")

    def _load_history(self):
        try:
            if os.path.exists(self.HISTORY_FILE):
                with open(self.HISTORY_FILE) as f:
                    self.history = json.load(f)
        except:
            self.history = []

    def _save_history(self):
        try:
            with open(self.HISTORY_FILE, "w") as f:
                json.dump(self.history[-200:], f, indent=2)
        except:
            pass

    def _add_history(self, title, path):
        entry = {
            "title": title,
            "path": path,
            "timestamp": datetime.now().strftime("%d %b %Y  %H:%M"),
        }
        self.history.insert(0, entry)
        self._save_history()
        self.after(0, self._refresh_history_ui)

    def _refresh_history_ui(self):
        for w in self.history_widgets:
            w.destroy()
        self.history_widgets.clear()

        if not self.history:
            self.empty_hist_lbl.pack(expand=True, pady=80)
            return
        self.empty_hist_lbl.pack_forget()

        for entry in self.history[:100]:
            hw = HistoryItem(self.history_scroll, entry,
                             on_delete=self._delete_history_item)
            self.history_widgets.append(hw)

    def _delete_history_item(self, widget):
        entry = widget.entry
        if not config.get("skip_delete_warning"):
            self._show_delete_warning(entry, widget)
        else:
            self._do_delete(entry, widget)

    def _show_delete_warning(self, entry, widget):
        dlg = ctk.CTkToplevel(self)
        dlg.title("Confirm Delete")
        dlg.configure(fg_color=BG_DEEP)
        dlg.resizable(False, False)
        dlg.geometry("400x220")
        dlg.grab_set()
        dlg.attributes("-topmost", True)

        frame = ctk.CTkFrame(dlg, fg_color=GLASS_BG, corner_radius=20,
                             border_width=1, border_color=WARNING_ORG)
        frame.pack(fill="both", expand=True, padx=2, pady=2)

        ctk.CTkLabel(frame, text="🗑  Delete File?",
                     font=("Segoe UI", 14, "bold"),
                     text_color=WARNING_ORG).pack(pady=(20, 6))

        name = os.path.basename(entry.get("path", ""))
        ctk.CTkLabel(frame, text=f"This will delete:\n{name[:45]}",
                     font=("Segoe UI", 11), text_color=TEXT_DIM,
                     wraplength=350).pack(pady=4)

        skip_var = tk.BooleanVar()
        ctk.CTkCheckBox(frame, text="Don't show this warning again",
                        variable=skip_var, font=("Segoe UI", 10),
                        text_color=TEXT_DIM, fg_color=BLUE_ACCENT,
                        border_color=GLASS_BORDER, corner_radius=5).pack(pady=8)

        btn_row = ctk.CTkFrame(frame, fg_color="transparent")
        btn_row.pack()

        def confirm():
            if skip_var.get():
                config.set("skip_delete_warning", True)
            dlg.destroy()
            self._do_delete(entry, widget)

        ctk.CTkButton(btn_row, text="Delete", width=100, height=32,
                      corner_radius=14, fg_color=ERROR_RED,
                      hover_color="#C0392B", command=confirm).pack(side="left", padx=8)
        ctk.CTkButton(btn_row, text="Cancel", width=100, height=32,
                      corner_radius=14, fg_color=GLASS_BORDER,
                      hover_color=BLUE_ACCENT, command=dlg.destroy).pack(side="left", padx=8)

    def _do_delete(self, entry, widget):
        path = entry.get("path", "")
        try:
            if os.path.exists(path):
                os.remove(path)
        except Exception as e:
            ErrorDialog(self, "Delete Error", str(e))
        if entry in self.history:
            self.history.remove(entry)
        self._save_history()
        widget.destroy()
        if widget in self.history_widgets:
            self.history_widgets.remove(widget)

    def _delete_selected(self):
        selected = [w for w in self.history_widgets if w.is_selected()]
        if not selected:
            return
        if not config.get("skip_delete_warning"):
            self._show_bulk_delete_warning(selected)
        else:
            for w in selected:
                self._do_delete(w.entry, w)

    def _show_bulk_delete_warning(self, widgets):
        dlg = ctk.CTkToplevel(self)
        dlg.title("Confirm Bulk Delete")
        dlg.configure(fg_color=BG_DEEP)
        dlg.resizable(False, False)
        dlg.geometry("380x200")
        dlg.grab_set()
        dlg.attributes("-topmost", True)

        frame = ctk.CTkFrame(dlg, fg_color=GLASS_BG, corner_radius=20,
                             border_width=1, border_color=WARNING_ORG)
        frame.pack(fill="both", expand=True, padx=2, pady=2)

        ctk.CTkLabel(frame, text=f"Delete {len(widgets)} file(s)?",
                     font=("Segoe UI", 14, "bold"),
                     text_color=WARNING_ORG).pack(pady=(20, 6))
        ctk.CTkLabel(frame, text="Files will be permanently deleted from your system.",
                     font=("Segoe UI", 11), text_color=TEXT_DIM,
                     wraplength=330).pack(pady=4)

        skip_var = tk.BooleanVar()
        ctk.CTkCheckBox(frame, text="Don't show again", variable=skip_var,
                        font=("Segoe UI", 10), text_color=TEXT_DIM,
                        fg_color=BLUE_ACCENT, border_color=GLASS_BORDER,
                        corner_radius=5).pack(pady=6)

        btn_row = ctk.CTkFrame(frame, fg_color="transparent")
        btn_row.pack()

        def confirm():
            if skip_var.get():
                config.set("skip_delete_warning", True)
            dlg.destroy()
            for w in widgets:
                self._do_delete(w.entry, w)

        ctk.CTkButton(btn_row, text="Delete All", width=110, height=32,
                      corner_radius=14, fg_color=ERROR_RED,
                      hover_color="#C0392B", command=confirm).pack(side="left", padx=8)
        ctk.CTkButton(btn_row, text="Cancel", width=100, height=32,
                      corner_radius=14, fg_color=GLASS_BORDER,
                      hover_color=BLUE_ACCENT, command=dlg.destroy).pack(side="left", padx=8)

    # ── Options Handlers ──────────────────────────────────────────────────────
    def _on_platform_change(self, val):
        config.set("platform", val)
        if val == "YouTube Music":
            self.quality_var.set("Audio Only (MP3)")
            self._on_quality_change("Audio Only (MP3)")

    def _on_quality_change(self, val):
        config.set("video_quality", val)
        tab = self.tabs.tab("⬇  Download")
        scroll = tab.winfo_children()[0]
        opt_card = scroll.winfo_children()[1]
        opt_grid = opt_card.winfo_children()[1]
        if val == "Audio Only (MP3)":
            self.audio_lbl.grid(row=2, column=0, sticky="w", pady=(4, 0))
            self.audio_menu.grid(row=3, column=0, sticky="w")
        else:
            self.audio_lbl.grid_remove()
            self.audio_menu.grid_remove()

    def _on_remember(self):
        val = self.remember_var.get()
        config.set("remember_path", val)
        if val:
            config.set("download_path", self.path_var.get())

    def _browse_path(self):
        folder = filedialog.askdirectory(initialdir=self.path_var.get())
        if folder:
            self.path_var.set(folder)
            if self.remember_var.get():
                config.set("download_path", folder)

    # ── System Tray ───────────────────────────────────────────────────────────
    def _setup_tray(self):
        try:
            import pystray
            from PIL import Image, ImageDraw

            img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
            d   = ImageDraw.Draw(img)
            d.ellipse([4, 4, 60, 60], fill=(75, 123, 236, 255))
            d.text((18, 18), "DL", fill="white")

            menu = pystray.Menu(
                pystray.MenuItem("Show DL Mongoose", self._show_from_tray, default=True),
                pystray.MenuItem("Quit", self._quit_app),
            )
            self.tray_icon = pystray.Icon("dlmongoose", img, APP_NAME, menu)
        except Exception:
            self.tray_icon = None

    def _minimize_to_tray(self):
        if self.tray_icon:
            self.withdraw()
            threading.Thread(target=self.tray_icon.run, daemon=True).start()
        else:
            self.iconify()

    def _show_from_tray(self, icon=None, item=None):
        if self.tray_icon:
            try:
                self.tray_icon.stop()
            except:
                pass
        self.after(0, self.deiconify)

    # ── Misc ──────────────────────────────────────────────────────────────────
    def _open_support(self):
        import webbrowser
        webbrowser.open("https://buymeacoffee.com/dlmongoose")

    def _on_close(self):
        if config.get("minimize_to_tray") and self.tray_icon:
            self._minimize_to_tray()
        else:
            self._quit_app()

    def _quit_app(self, icon=None, item=None):
        if self.tray_icon:
            try:
                self.tray_icon.stop()
            except:
                pass
        self.destroy()


# ══════════════════════════════════════════════════════════════════════════════
#  ENTRY POINT
# ══════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    # Show splash first
    root = DLMongoose()
    root.withdraw()

    splash = SplashScreen()
    splash.wait_window()

    # Check internet on launch
    if not check_internet():
        root.internet_ok = False
        root.after(500, root._show_no_internet)

    root.deiconify()
    root.mainloop()
